# Mi Biblioteca

Aplicación de consola para registrar libros y series, consultar la biblioteca, marcar obras como terminadas y recibir recomendaciones según tus calificaciones.

## Cómo ejecutar el programa

Descomprime el ZIP y abre una terminal dentro de la carpeta `Mi_Biblioteca`. Ejecuta con Python 3.8 o superior.

```bash
python main.py
```

El programa usa solo la biblioteca estándar de Python.

## Qué hace cada archivo

| Archivo | Responsabilidad |
| --- | --- |
| `main.py` | Carga los datos y coordina el menú, el guardado y la salida. |
| `consola.py` | Pide los datos, muestra los menús y presenta los resultados. |
| `biblioteca.py` | Define las obras y aplica las reglas de registro, consulta, cambio de estado y recomendación. |
| `almacenamiento.py` | Lee y guarda las obras en el archivo de texto. |
| `biblioteca.txt` | Contiene las siete obras de ejemplo y almacena las que agregues. |

La biblioteca guarda las obras en un diccionario. Cada clave es el título sin espacios al inicio o al final y sin distinguir mayúsculas. Las consultas devuelven listas de obras en el orden en que se registraron.

## Cómo probarlo

1. Selecciona **3**. Con los datos iniciales, obtendrás **El Hobbit** porque **Harry Potter** tiene la calificación más alta y ambos son de fantasía.
2. Selecciona **1** para registrar una obra y luego **2** para consultarla. Puedes ver todas las obras o filtrar por género o estado.
3. Selecciona **6**, elige un libro o una serie de la lista de pendientes y dale una calificación del **1 al 5**. La obra aparecerá como terminada y su calificación se tendrá en cuenta en las recomendaciones.
4. Selecciona **4** para guardar o **5** para guardar y salir. Al abrir el programa de nuevo, encontrarás tus obras y los cambios de estado y calificación.

Si varias obras terminadas comparten la calificación más alta, se toma la primera según el orden de registro. Si falta `biblioteca.txt`, el programa empieza con una biblioteca vacía y crea el archivo al guardar.
