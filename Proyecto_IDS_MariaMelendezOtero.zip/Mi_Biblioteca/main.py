"""Punto de entrada de Mi Biblioteca."""

from pathlib import Path

from almacenamiento import cargar_biblioteca, guardar_biblioteca
from biblioteca import Biblioteca
from consola import (
    consultar_obras,
    mostrar_menu,
    mostrar_recomendacion,
    registrar_obra,
    terminar_obra,
)


RUTA_DATOS = Path(__file__).resolve().with_name("biblioteca.txt")


def main():
    try:
        biblioteca = cargar_biblioteca(RUTA_DATOS)
    except FileNotFoundError:
        print("No se encontró biblioteca.txt. Se inicia una biblioteca vacía.")
        biblioteca = Biblioteca()
    except (OSError, ValueError) as error:
        print(f"No se pudo cargar la biblioteca. {error}")
        return

    while True:
        opcion = mostrar_menu()
        if opcion == 1:
            registrar_obra(biblioteca)
        elif opcion == 2:
            consultar_obras(biblioteca)
        elif opcion == 3:
            mostrar_recomendacion(biblioteca)
        elif opcion == 6:
            terminar_obra(biblioteca)
        elif opcion in (4, 5):
            try:
                guardar_biblioteca(RUTA_DATOS, biblioteca.consultar())
            except OSError as error:
                print(f"No se pudo guardar la biblioteca. {error}")
                continue
            print("Biblioteca guardada.")
            if opcion == 5:
                print("Hasta pronto.")
                break


main()
