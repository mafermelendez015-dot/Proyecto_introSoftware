"""Obras y reglas de la biblioteca personal."""

TIPOS = ("libro", "serie")
ESTADOS = ("pendiente", "terminado")


def validar_texto(texto, campo):
    texto = texto.strip()
    if not texto:
        raise ValueError(f"El {campo} no puede estar vacío.")
    if ";" in texto or "\n" in texto or "\r" in texto:
        raise ValueError(f"El {campo} no puede contener punto y coma (;) ni saltos de línea.")
    return texto


class Obra:
    def __init__(self, titulo, tipo, genero, estado, calificacion):
        self.titulo = validar_texto(titulo, "título")
        self.genero = validar_texto(genero, "género").lower()
        if tipo not in TIPOS:
            raise ValueError("El tipo debe ser libro o serie.")
        if estado not in ESTADOS:
            raise ValueError("El estado debe ser pendiente o terminado.")
        if type(calificacion) is not int:
            raise ValueError("La calificación debe ser un número entero.")
        if estado == "pendiente" and calificacion != 0:
            raise ValueError("Una obra pendiente debe tener calificación 0.")
        if estado == "terminado" and not 1 <= calificacion <= 5:
            raise ValueError("La calificación debe estar entre 1 y 5.")
        self.tipo = tipo
        self.estado = estado
        self.calificacion = calificacion


class Biblioteca:
    def __init__(self):
        self._obras = {}

    def existe_titulo(self, titulo):
        clave = titulo.strip().casefold()
        return clave in self._obras

    def registrar(self, obra):
        clave = obra.titulo.strip().casefold()
        if clave in self._obras:
            raise ValueError("La obra ya está registrada.")
        self._obras[clave] = obra

    def marcar_como_terminada(self, titulo, calificacion):
        clave = titulo.strip().casefold()
        obra = self._obras.get(clave)
        if obra is None:
            raise ValueError("La obra no está registrada.")
        if obra.estado != "pendiente":
            raise ValueError("La obra ya está terminada.")
        self._obras[clave] = Obra(
            obra.titulo, obra.tipo, obra.genero, "terminado", calificacion
        )

    def consultar(self, *, genero=None, estado=None):
        return [
            obra
            for obra in self._obras.values()
            if (genero is None or obra.genero == genero.strip().lower())
            and (estado is None or obra.estado == estado)
        ]

    def recomendar(self):
        pendientes = self.consultar(estado="pendiente")
        if not pendientes:
            return None
        mejor = max(
            self.consultar(estado="terminado"),
            key=lambda obra: obra.calificacion,
            default=None,
        )
        if mejor is not None:
            for obra in pendientes:
                if obra.genero == mejor.genero:
                    return obra
        return pendientes[0]
