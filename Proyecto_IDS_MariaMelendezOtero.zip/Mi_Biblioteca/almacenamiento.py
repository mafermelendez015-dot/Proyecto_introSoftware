"""Lectura y escritura del archivo de texto de la biblioteca."""

from pathlib import Path
from tempfile import NamedTemporaryFile

from biblioteca import Biblioteca, Obra


def cargar_biblioteca(ruta):
    biblioteca = Biblioteca()
    with ruta.open(encoding="utf-8-sig") as archivo:
        for numero, linea in enumerate(archivo, start=1):
            if not linea.strip():
                continue
            try:
                titulo, tipo, genero, estado, calificacion = linea.rstrip("\r\n").split(";")
                biblioteca.registrar(Obra(titulo, tipo, genero, estado, int(calificacion)))
            except ValueError as error:
                raise ValueError(f"Datos inválidos en {ruta.name}, línea {numero}: {error}") from error
    return biblioteca


def guardar_biblioteca(ruta, obras):
    temporal = None
    try:
        with NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=ruta.parent, delete=False
        ) as archivo:
            temporal = Path(archivo.name)
            for obra in obras:
                campos = (obra.titulo, obra.tipo, obra.genero, obra.estado, str(obra.calificacion))
                archivo.write(";".join(campos) + "\n")
        temporal.replace(ruta)
    finally:
        if temporal is not None:
            temporal.unlink(missing_ok=True)
