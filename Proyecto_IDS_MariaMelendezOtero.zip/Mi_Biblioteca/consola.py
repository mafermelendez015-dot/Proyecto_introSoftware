"""Menús, mensajes y captura de datos por consola."""

from biblioteca import ESTADOS, TIPOS, Obra, validar_texto


def mostrar_menu():
    print("\nMi Biblioteca")
    print("1. Registrar una obra")
    print("2. Consultar la biblioteca")
    print("3. ¿Qué leo o veo hoy?")
    print("4. Guardar")
    print("5. Salir")
    print("6. Marcar una obra como terminada")
    try:
        opcion = int(input("Elige una opción: "))
    except ValueError:
        print("Debe escribir un número del 1 al 6")
        return None
    if not 1 <= opcion <= 6:
        print("La opción está fuera de rango. Elige del 1 al 6.")
        return None
    return opcion


def pedir_texto(campo):
    while True:
        try:
            return validar_texto(input(f"{campo.capitalize()}: "), campo)
        except ValueError as error:
            print(error)


def pedir_opcion(pregunta, opciones):
    validas = ", ".join(opciones)
    while True:
        respuesta = input(f"{pregunta} ({validas}): ").strip().lower()
        if respuesta in opciones:
            return respuesta
        print(f"Opciones válidas: {validas}.")


def pedir_calificacion():
    while True:
        try:
            calificacion = int(input("Calificación (1 a 5): "))
        except ValueError:
            print("La calificación debe ser un número entero.")
            continue
        if 1 <= calificacion <= 5:
            return calificacion
        print("La calificación debe estar entre 1 y 5.")


def registrar_obra(biblioteca):
    titulo = pedir_texto("título")
    if biblioteca.existe_titulo(titulo):
        print("La obra ya está registrada.")
        return
    tipo = pedir_opcion("Tipo", TIPOS)
    genero = pedir_texto("género")
    estado = pedir_opcion("Estado", ESTADOS)
    calificacion = pedir_calificacion() if estado == "terminado" else 0
    biblioteca.registrar(Obra(titulo, tipo, genero, estado, calificacion))
    print("Obra registrada.")


def terminar_obra(biblioteca):
    pendientes = biblioteca.consultar(estado="pendiente")
    if not pendientes:
        print("No hay obras pendientes.")
        return

    print("\nObras pendientes")
    for numero, obra in enumerate(pendientes, start=1):
        print(f"{numero}. {obra.titulo} ({obra.tipo})")
    print("0. Volver al menú")
    opciones = tuple(str(numero) for numero in range(len(pendientes) + 1))
    opcion = int(pedir_opcion("Elige una obra", opciones))
    if opcion == 0:
        return

    obra = pendientes[opcion - 1]
    calificacion = pedir_calificacion()
    biblioteca.marcar_como_terminada(obra.titulo, calificacion)
    print(f"{obra.titulo} quedó en estado terminado con una calificación de {calificacion}/5.")


def consultar_obras(biblioteca):
    print("\n1. Todas las obras")
    print("2. Filtrar por género")
    print("3. Filtrar por estado")
    opcion = pedir_opcion("Elige una consulta", ("1", "2", "3"))
    if opcion == "2":
        obras = biblioteca.consultar(genero=pedir_texto("género"))
    elif opcion == "3":
        obras = biblioteca.consultar(estado=pedir_opcion("Estado", ESTADOS))
    else:
        obras = biblioteca.consultar()
    if not obras:
        print("No hay obras registradas." if opcion == "1" else "No hay obras con ese filtro.")
        return
    for obra in obras:
        calificacion = str(obra.calificacion) if obra.calificacion else "Sin calificar"
        print(f"- {obra.titulo} | {obra.tipo} | {obra.genero} | {obra.estado} | {calificacion}")


def mostrar_recomendacion(biblioteca):
    obra = biblioteca.recomendar()
    if obra is None:
        print("No hay obras pendientes para recomendar.")
    else:
        print(f"Te recomendamos {obra.titulo} ({obra.tipo}, {obra.genero}).")
